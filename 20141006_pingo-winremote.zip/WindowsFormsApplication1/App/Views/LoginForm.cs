﻿using System;
using System.Globalization;
using System.Windows.Forms;
using WinRemote.App.Views;

namespace WinRemote
{
    public partial class LoginForm : Form
    {
        private void translate()
        {
            if (CultureInfo.CurrentCulture.Name.Contains("de"))
            {
                InfoLoginLabel.Text = Properties.translate_de.LoginInfo;
                InfoLoginLabel.Text += '\n' + Properties.translate_de.LoginInfo2;
                MailLabel.Text = Properties.translate_de.Mail;
                PasswordLabel.Text = Properties.translate_de.Password;
                SignUpLabel.Text = Properties.translate_de.SignUp;
                SettingsButton.Text = Properties.translate_de.Settings;
            }
            else
            {
                InfoLoginLabel.Text = Properties.translate.LoginInfo;
                InfoLoginLabel.Text += '\n' + Properties.translate.LoginInfo2;
                MailLabel.Text = Properties.translate.Mail;
                PasswordLabel.Text = Properties.translate.Password;
                SignUpLabel.Text = Properties.translate.SignUp;
                SettingsButton.Text = Properties.translate.Settings;
            }
        }

        #region fields
        /// <summary>
        /// Event is called when a login attempt was successful
        /// </summary>
        public event EventHandler AuthSuccess;
        /// <summary>
        /// Necessary to manage the AuthSuccess Event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public delegate void EventHandler(object sender, EventArgs e);
        /// <summary>
        /// true if login was successful
        /// </summary>
        private bool success = false;
        #endregion

        #region methods
        /// <summary>
        /// Initialize and translate
        /// </summary>
        public LoginForm()
        {
            InitializeComponent();

            translate();
        }

       
        /// <summary>
        /// Is called when the user presses the submit button and tries to log in.
        /// If the token is not valid, the user is asked to type in his data again or
        /// create an account. If it is valid, the auth token is stored and the user can
        /// operate on the MainForm.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SubmitLogin_Click(object sender, EventArgs e)
        {
            var auth_token = User.authenticate(MailText.Text, PasswordText.Text);

            if (auth_token.Equals("invalid"))
            {
                NotificationHelper.ShowError(Properties.translate.InvalidData);
                MailText.Text = "";
                PasswordText.Text = "";
            }
            else
            {
                DBController.StoreAuthToken(auth_token);
                Settings.AUTH_TOKEN = auth_token;
                AuthSuccess(this, new EventArgs());
                success = true;
                this.Close();
            }
        }
        /// <summary>
        /// Is called when form is closed. If user is not successfully logged in, it will shut down the app.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoginForm_Close(object sender, EventArgs e)
        {
            if (!success)
            {
               
                    Awesomium.Core.WebCore.Shutdown();
                    Application.Exit();
               
            }
        }
        /// <summary>
        /// Called when the form is loaded. Sets the AcceptButton to the SubmitButton so it is pressed on pressing Enter.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoginForm_Load(object sender, EventArgs e)
        {
            AcceptButton = SubmitLogin;
        }

        /// <summary>
        /// Called when the SignUp link is clicked. Opens the SignUp Base URL from Settings in the Default Browser.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SignUpLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string goTo = Settings.BASE_SIGN_UP_URL;
            //Open URL with Default Browser
            System.Diagnostics.Process.Start(goTo);
        }
        #endregion

        private void SettingsButton_Click(object sender, EventArgs e)
        {
            new SettingsForm().ShowDialog(this);
        }
    }
}