﻿using AppLimit.NetSparkle;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinRemote.App.Views
{
   

    public partial class SettingsForm : Form
    {
        private Sparkle _sparkle;

        public SettingsForm()
        {
            InitializeComponent();
            translate();
        }

        private void translate()
        {
            if (CultureInfo.CurrentCulture.Name.Contains("de"))
            {
                InfoSettingsLabel.Text = Properties.translate_de.SettingsInfo;
                SaveButton.Text = Properties.translate_de.SaveChanges;
                DiscardButton.Text = Properties.translate_de.DiscardChanges;
                ResetButton.Text = Properties.translate_de.ResetToDefault;
            }
            else
            {
                InfoSettingsLabel.Text = Properties.translate.SettingsInfo;
                SaveButton.Text = Properties.translate.SaveChanges;
                DiscardButton.Text = Properties.translate.DiscardChanges;
                ResetButton.Text = Properties.translate.ResetToDefault;
            }
        }

        private void SettingsForm_Load(object sender, EventArgs e)
        {
            SiteURLText.Text = Settings.BASE_URL;
            SocketURLText.Text = Settings.BASE_SOCKET_URL;
        }

        private void DiscardButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            SiteURLText.Text = Settings.DEFAULT_URL;
            SocketURLText.Text = Settings.DEFAULT_SOCKET_URL;
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            Settings.BASE_URL = SiteURLText.Text;
            if (!Settings.BASE_URL.Contains("http") && !Settings.BASE_URL.Contains("https")) Settings.BASE_URL = "https://" + Settings.BASE_URL;
            Settings.BASE_SOCKET_URL = SocketURLText.Text;
            if (!Settings.BASE_SOCKET_URL.Contains("http") && !Settings.BASE_SOCKET_URL.Contains("https")) Settings.BASE_SOCKET_URL = "http://" + Settings.BASE_SOCKET_URL;
            DBController.StoreURLs(Settings.BASE_URL, Settings.BASE_SOCKET_URL);
            this.Close();
        }
    }
}
