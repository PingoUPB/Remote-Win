﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace WinRemote
{
    /// <summary>
    /// Holds any relevant logic(eventhandlers, etc.) behin the main application window.
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        /// Sets default translation based on resource files.
        /// </summary>
        public void translate()
        {

            if (CultureInfo.CurrentCulture.Name.Contains("de"))
            {
                InfoSessionLabel.Text = Properties.translate_de.SessionInfo;
                LogoutButton.Text = Properties.translate_de.Logout;
                QuickDurationTextLabel.Text = Properties.translate_de.Duration;
                CatalogueDurationLabel.Text = Properties.translate_de.Duration;
                CatalogueTab.Text = Properties.translate_de.Catalogue;
                QuickstartTab.Text = Properties.translate_de.Quickstart;
                QTypeLabel.Text = Properties.translate_de.QuestionType;
                QuestionLabel.Text = Properties.translate_de.Question;
                OptionLabel.Text = Properties.translate_de.Options;
            }
            else
            {
                InfoSessionLabel.Text = Properties.translate.SessionInfo;
                LogoutButton.Text = Properties.translate.Logout;
                QuickDurationTextLabel.Text = Properties.translate.Duration;
                CatalogueDurationLabel.Text = Properties.translate.Duration;
                CatalogueTab.Text = Properties.translate.Catalogue;
                QuickstartTab.Text = Properties.translate.Quickstart;
                QTypeLabel.Text = Properties.translate.QuestionType;
                QuestionLabel.Text = Properties.translate.Question;
                OptionLabel.Text = Properties.translate.Options;
            }
        }

        #region fields
        /// <summary>
        /// Current xposition of the window. Needed for maximize and minimize behaviour. Ignores position changes due to max- or minimizing.
        /// </summary>
        private int currentxpos;

        /// <summary>
        /// Current yposition of the window. Needed for maximize and minimize behaviour. Ignores position changes due to max- or minimizing.
        /// </summary>
        private int currentypos;

        /// <summary>
        /// true, when window is being minimized, else false.
        /// </summary>
        private bool isminimized = false;

        /// <summary>
        /// true, when form is ready to recieve further countdown messages from websocket.
        /// </summary>
        private bool countdownmessagesrecievable = true;

        /// <summary>
        /// true, when results of the latest survey are ready to be displayed.
        /// </summary>
        private bool resultsthere = false;
        /// <summary>
        /// true, when a survey is currently running.
        /// </summary>
        private Boolean runningsurvey = false;
       

        /// <summary>
        /// empty delegate function, needed for calling methods from another thread.
        /// </summary>
        public delegate void emptyFunction();
        #endregion

        #region initializing and authenticating
        /// <summary>
        /// Initializes the form, adds translation and places it at the bottom right corner of the user's display.
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
            //Wanna test english language?
            //Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en-US");
            this.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - this.Width, Screen.PrimaryScreen.WorkingArea.Height - this.Height);
            translate();
            
        }

     

     
        /// <summary>
        /// Is called on loading the form. Basically checks for validity of user's authentication token.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_Load(object sender, EventArgs e)
        {

            string base_URL = DBController.RetrieveBaseURL();
            string base_socket_URL = DBController.RetrieveBaseSocketURL();

            if (base_URL.Length > 0 && base_socket_URL.Length > 0)
            {
                Settings.BASE_URL = base_URL;
                Settings.BASE_SOCKET_URL = base_socket_URL;
            }

            string auth_token = DBController.RetrieveAuthToken();//get token from db

            if (auth_token == null || !User.valid_token(auth_token))//token is not valid
            {
                //open LoginForm and subscribe to a successful authentication
                var login = new LoginForm();
                login.AuthSuccess += new WinRemote.LoginForm.EventHandler(this.AuthSuccessListener);
                login.ShowDialog();
            }

            else//token is valid
            {
                Settings.AUTH_TOKEN = auth_token;
                Settings.ListBuilding();
                BuildLists();
                new Thread(new ThreadStart(new emptyFunction(delegate() { Browser.Start(Settings.BASE_URL, false); }))).Start();
            }

            
            
        }
        /// <summary>
        /// Listener for successful authentication. Initializes lists when successful.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AuthSuccessListener(object sender, EventArgs e)
        {
            Settings.ListBuilding();
            BuildLists();
        }

        /// <summary>
        /// Has to be called before displaying the form. Initializes any needed dropdown menus and checks for the user's
        /// session and question collection.
        /// </summary>
        public void BuildLists()
        {
            Startsettings.get();//get default quickstart settings from PINGO server
            //Create lists in the quickstart tab, preselect the first items in list
            ChooseType.Items.AddRange(Startsettings.TypeList.ToArray());
            ChooseType.SelectedItem = ChooseType.Items[0];
            ChooseQuickDuration.Items.AddRange(Startsettings.DURATION_CHOICES.ToArray());
            ChooseQuickDuration.SelectedItem = ChooseQuickDuration.Items[0];
            ChooseDuration.Items.AddRange(Startsettings.DURATION_CHOICES.ToArray());
            ChooseDuration.SelectedItem = ChooseDuration.Items[0];

            //Create user's sessionlist
            var eventarr = Event.All().ToArray();
            SessionList.Items.AddRange(eventarr);
            if (SessionList.Items.Count == 0)//user has no sessions
            {
                //The user will be logged out and asked to create sessions with his logged in account
                NotificationHelper.ShowError(Properties.translate.NoSessionError);
                clearLists();
                User.Logout();//logging out the user gives the opportunity to sign in with another account
                var lf = new LoginForm();
                lf.ShowDialog();
            }
            else//user has sessions, preselect the first in list
                SessionList.SelectedItem = eventarr[0];
            //Initialize tag dropdown menu
            ChooseTag.Items.Add(Properties.translate.AllTags);
            ChooseTag.SelectedItem = Properties.translate.AllTags;
            var taglist = new List<string>();
            foreach (string s in Settings.Tagtable.Keys)
                if (!s.Equals(Properties.translate.AllTags))
                    taglist.Add(s);
            taglist.Sort();
            ChooseTag.Items.AddRange(taglist.ToArray());
            //QuestionList is initialized dynamically, depending on the currently selected tag. Look at ChooseTag_selected_changed for more.
        }
        #endregion

        #region TabControl
        /// <summary>
        /// Prevents switching tabs when a survey is currently running.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Tab_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (runningsurvey)
                e.Cancel = true;
        }

        #endregion TabControl

        #region selecting from dropdown
        /// <summary>
        /// Changes the Session in the Settings according to the new choice. Updates the title of the window.
        /// -> Window will always display current session's name.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SessionList_SelectedIndexChanged(object sender, EventArgs e)
        {
            Settings.session = ((Event)(SessionList.SelectedItem));
            this.Text = Settings.session.Token;
        }
        /// <summary>
        /// Set's the DurationLabel's text to the chosen duration. Probably not necessary. Just to be sure.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChooseDuration_SelectedIndexChanged(object sender, EventArgs e)
        {
            DurationLabel.Text = ChooseDuration.SelectedItem.ToString();
        }
        /// <summary>
        /// Set's the QuickDurationLabel's text to the chosen duration. Probably not necessary. Just to be sure.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChooseQuickDuration_SelectedIndexChanged(object sender, EventArgs e)
        {
            QuickDurationLabel.Text = ChooseQuickDuration.SelectedItem.ToString();
        }
        /// <summary>
        /// Updates the question list according to the chosen tag. Disables starting a survey if no question is available for the 
        /// chosen tag.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChooseTag_SelectedIndexChanged(object sender, EventArgs e)
        {
            QuestionList.Items.Clear();
            QuestionList.Items.AddRange(((List<Question>)Settings.Tagtable[ChooseTag.SelectedItem]).ToArray()); //update QuestionList
            if (QuestionList.Items.Count == 0) //no question with such tag
            {
                StartSurvey.Visible = false;
                StopButton.Visible = false;
            }
            else //preselect first question, update tooltip(see below)
            {
                QuestionList.SelectedItem = QuestionList.Items[0];
                QuestionTooltip.SetToolTip(QuestionList, QuestionList.SelectedItem.ToString());
            }
        }
        /// <summary>
        /// Updates the textbox according to the chosen question. User's can read the full question's name in the
        /// textbox, while only seeing a small part of it in the dropdown. Furthermore updates the tooltip, which is shown, when
        /// hovering over the dropdown menu.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void QuestionList_SelectedIndexChanged(object sender, EventArgs e)
        {
            QuestionTextBox.Text = QuestionList.SelectedItem.ToString();
            QuestionTooltip.SetToolTip(QuestionList, QuestionList.SelectedItem.ToString());
        }
        /// <summary>
        /// Updates the option choice according to the selected question type.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChooseType_SelectedIndexChanged(object sender, EventArgs e)
        {
            SurveyType chosen = (SurveyType)ChooseType.SelectedItem;
            if (chosen.options.First().name.Equals(""))//Type has no options
            {
                OptionLabel.Visible = false;
                ChooseOptions.Visible = false;
            }
            else//Type has options
            {
                ChooseOptions.Items.Clear();
                ChooseOptions.Items.AddRange(chosen.options.ToArray());
                ChooseOptions.SelectedItem = ChooseOptions.Items[0];
                ChooseOptions.Visible = true;
                OptionLabel.Visible = true;
            }
        }
        #endregion

        #region switching beetween running and not running surveys

        /// <summary>
        /// Executes necessary changes when a survey ends. Disabling Stop buttons, enabling Start buttons, disabling countdown, enabling
        /// panels for selecting new questions or surveys.
        /// </summary>
        private void switchModeOff()
        {
            CatalogueQuestionPanel.Visible = true;
            QuickstartPanel.Visible = true;
            StartSurvey.Enabled = true;
            StartQuickSurvey.Enabled = true;
            QuickStopButton.Enabled = false;
            StopButton.Enabled = false;
            QuickDurationLabel.Visible = false;
            DurationLabel.Visible = false;
            ParticipantLabel.Visible = false;
            QuickParticipantLabel.Visible = false;
            runningsurvey = false;
        }

        /// <summary>
        /// Executes necessary changes when a survey starts. Enabling Stop buttons, disabling Start buttons, enabling countdown, disabling
        /// panels for selecting new questions or surveys.
        /// </summary>
        private void switchModeOn()
        {
            resultsthere = false;
            CatalogueQuestionPanel.Visible = false;
            QuickstartPanel.Visible = false;
            StartSurvey.Enabled = false;
            StartQuickSurvey.Enabled = false;
            QuickStopButton.Enabled = true;
            StopButton.Enabled = true;
            QuickDurationLabel.Visible = true;
            DurationLabel.Visible = true;
            ParticipantLabel.Visible = true;
            QuickParticipantLabel.Visible = true;
            runningsurvey = true;
        }

        #endregion switching beetween running and not running surveys

        #region start buttons
        /// <summary>
        /// Executed, when the start button in the quickstart tab is pressed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartQuickSurvey_Click(object sender, EventArgs e)
        {
            //Necessary adjustments when starting a survey
            string part;
            string load;
            if (CultureInfo.CurrentCulture.Name.Contains("de"))
            {
                part = Properties.translate_de.Participants;
                load = Properties.translate_de.load;
            }
            else
            {
                part = Properties.translate.Participants;
                load = Properties.translate.load;
            }

            QuickDurationLabel.Text = load;
            QuickParticipantLabel.Text = part + ": 0";
            switchModeOn();
            //Start the survey with socket, etc...
            click_action(sender, () => { Survey.PostSurvey(Settings.session.Token, ((SurveyType)ChooseType.SelectedItem).type, ((Duration)ChooseQuickDuration.SelectedItem).sec.ToString(), ((TypeOption)ChooseOptions.SelectedItem).name); });
        }
        /// <summary>
        /// Executed, when the start button in the catalogue tab is pressed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartSurvey_Click(object sender, EventArgs e)
        {
            string part;
            if (CultureInfo.CurrentCulture.Name.Contains("de"))
            {
                part = Properties.translate_de.Participants;
                DurationLabel.Text = Properties.translate_de.load;
            }
            else
            {
                part = Properties.translate.Participants;
                DurationLabel.Text = Properties.translate.load;
            }
            //Necessary adjustments when starting a survey
            
            ParticipantLabel.Text = part + ": 0";
            switchModeOn();
            //Start the survey with socket, etc...
            click_action(sender, () =>
            {
                Question.PostQuestion(Settings.session.Token, ((Question)(QuestionList.SelectedItem)).Id.ToString(), ((Duration)ChooseDuration.SelectedItem).sec.ToString());
            });
        }
        /// <summary>
        /// Posts the question/survey and starts the websocket connection.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="f">The action which executes posting the survey/question to the server.</param>
        private void click_action(object sender, Action f)
        {
            f();
            var sh = new SocketHelper();
            sh.CountdownChanged += new WinRemote.SocketHelper.SocketEventHandler(SocketCountdownMessageRecieved);
            sh.VotersChanged += new WinRemote.SocketHelper.SocketEventHandler(SocketVotersMessageRecieved);
            sh.Execute();
            Settings.session.ReloadLatestSurvey();
            //Subscribing for countdown and voter count of the started survey
            sh.SubscribeToSurveyCountdown(Settings.session.LatestSurvey.Id);
            sh.SubscribeToSurveyVoters(Settings.session.LatestSurvey.Id);
        }
        #endregion

        #region stop buttons
        /// <summary>
        /// Executed when a survey from a catalogue question is being stopped.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StopButton_Click(object sender, EventArgs e)
        {
            click_stop(sender);
        }
        /// <summary>
        /// Executed when a survey from quickstart menu is being stopped.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void QuickStopButton_Click(object sender, EventArgs e)
        {
            click_stop(sender);
        }
        /// <summary>
        /// Necessary prompts for stopping a survey: Calling the StopSurvey Method and sending a message to the listeners
        /// of the websocket on stopping the survey manually.
        /// </summary>
        /// <param name="sender"></param>
        private void click_stop(object sender)
        {
            Survey.StopSurvey(Settings.session);
            var sh = new SocketHelper();
            SocketCountdownMessageRecieved(sh, new SocketEventArgs("stopped manually"));
        }
        #endregion

        #region logout
        /// <summary>
        /// Performs clearLists and logs the user out thus showing the login in dialog again.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LogoutButton_Click(object sender, EventArgs e)
        {
            clearLists();
            User.Logout();
            //show Login again
            var login = new LoginForm();
            login.AuthSuccess += new WinRemote.LoginForm.EventHandler(this.AuthSuccessListener);
            login.ShowDialog();
        }

        /// <summary>
        /// Clears all dropdown lists. Necessary for logout.
        /// </summary>
        private void clearLists()
        {
            SessionList.Items.Clear();
            QuestionList.Items.Clear();
            ChooseTag.Items.Clear();
            ChooseDuration.Items.Clear();
            ChooseType.Items.Clear();
            ChooseQuickDuration.Items.Clear();
        }

        #endregion

        #region listening to socket events
        /// <summary>
        /// Called when the countdown needs to be updated. Updates the countdowns and opens the built in webbrowser with the
        /// result page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SocketCountdownMessageRecieved(object sender, SocketEventArgs e)
        {
            var payload = e.payload;
            if (payload.Equals("stopped") || !countdownmessagesrecievable) return; //do not accept any more messages
            if (payload.Equals("stopped manually")) { payload = "0"; countdownmessagesrecievable = false; } //stop button was pressed
            //Update countdowns
            DurationLabel.Invoke(new emptyFunction(delegate() { DurationLabel.Text = Duration.ConvertSeconds(Convert.ToInt32(Convert.ToDouble(payload))); }));
            QuickDurationLabel.Invoke(new emptyFunction(delegate() { QuickDurationLabel.Text = Duration.ConvertSeconds(Convert.ToInt32(Convert.ToDouble(payload))); }));
            if (Convert.ToDouble(payload) == 0 && !resultsthere) //time to show results
            {
                countdownmessagesrecievable = false;
                resultsthere = true;
                Settings.session.ReloadLatestSurvey();

                //Open the result page. By convention with developement team, this is the default result page and the parameter remote_view=true
                Browser.Start(Settings.BASE_URL + "/events/" + Settings.session.Token + "/surveys/" + Settings.session.LatestSurvey.Id + "/?auth_token=" + Settings.AUTH_TOKEN + "&remote_view=true");
                //prepare to start new survey
                this.Invoke(new emptyFunction(delegate() { this.switchModeOff(); })); //needs to be called with invoke, because called from socket thread
                countdownmessagesrecievable = true;
            }
        }

        /// <summary>
        /// Called when socket informs on a changed number of current voters. Updates the participants labels to display the
        /// number of current voters properly.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SocketVotersMessageRecieved(object sender, SocketEventArgs e)
        {
            //need to be called with invoke, because this method is called from another thread, namely the socket thread
            string part;
            if (CultureInfo.CurrentCulture.Name.Contains("de"))
                part = Properties.translate_de.Participants;
            else
                part = Properties.translate.Participants;
            ParticipantLabel.Invoke(new emptyFunction(delegate() { ParticipantLabel.Text = part + ": " + e.payload; }));
            QuickParticipantLabel.Invoke(new emptyFunction(delegate() { QuickParticipantLabel.Text = part + ": " + e.payload; }));
        }
        #endregion

        #region maximinimize change

        /// <summary>
        /// Overrides default maximized and minimized behaviour. On maximiziation, the window returns to it's last position before it was 
        /// minimized. On minimization the window is only set to it's minimal size and does not disappear in the task bar.
        /// </summary>
        /// <param name="m"></param>
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0112) // WM_SYSCOMMAND
            {
                // Check window state 
                if (m.WParam == new IntPtr(0xF030)) // Maximize event - SC_MAXIMIZE from Winuser.h
                {
                    // The window is being maximized
                    this.Size = this.MaximumSize;

                    this.Location = new Point(currentxpos, currentypos);

                    return;
                }
                if (m.WParam == new IntPtr(0xF020))
                {//window is being minimized
                    this.isminimized = true;
                    this.Size = this.MinimumSize;
                    //go to bottom right corner
                    this.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - this.Width, Screen.PrimaryScreen.WorkingArea.Height - this.Height);
                    this.isminimized = false;
                    return;
                }
            }
            base.WndProc(ref m); //call default max and min procedure.
        }

        /// <summary>
        /// Updates current x and y pos, if window is not minimized currently.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_LocationChanged(object sender, EventArgs e)
        {
            if (!isminimized)
            {
                this.currentxpos = this.Location.X;
                this.currentypos = this.Location.Y;
            }
        }

        #endregion maximinimize change

        /// <summary>
        /// Called on closing the form. Shutdowns the Webcore of the built-in webbrowser.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_Close(object sender, EventArgs e)
        {
            Awesomium.Core.WebCore.Shutdown();
        }
      
    }
}