﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinRemote.App.Models
{
    class URLSettings
    {
        public String base_URL {get;set;}
        public String base_Socket_URL { get; set; }

        public URLSettings(String base_URL, String base_Socket_URL)
        {
            this.base_URL = base_URL;
            this.base_Socket_URL = base_Socket_URL;
        }
    }
}
