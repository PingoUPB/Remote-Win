﻿using Newtonsoft.Json.Linq;

namespace WinRemote
{
    /// <summary>
    /// Survey class similiar to the survey model in PINGO Webapp
    /// </summary>
    public class Survey : WSType
    {
        #region fields
        /// <summary>
        /// survey's ID
        /// </summary>
        public string Id { get; set; }
        /// <summary>

        /// <summary>
        /// survey's name/title
        /// </summary>
        public string Name { get; set; }

        #endregion

        #region methods
        /// <summary>
        /// Converts a JToken into a survey.
        /// </summary>
        /// <param name="s">the JToken to be converted</param>
        /// <returns>survey object with name and id</returns>
        public static Survey FromJson(JToken s)
        {
            var su = new Survey();
            su.Name = (string)s["name"];
            su.Id = (string)s["_id"];
            return su;
        }

        /// <summary>
        /// Posts a survey to the PINGO server
        /// </summary>
        /// <param name="eventToken">the event's token where the survey is posted in</param>
        /// <param name="type">the survey's type</param>
        /// <param name="duration">the survey's duration</param>
        /// <param name="options">the survey's options</param>
        public static void PostSurvey(string eventToken, string type, string duration, string options)
        {
            WSHelper<Question> wsh = new WSHelper<Question>();
            var paramlist = new System.Collections.Hashtable();
            //Add the parameters
            paramlist.Add("id", eventToken);
            paramlist.Add("options", options);
            paramlist.Add("auth_token", Settings.AUTH_TOKEN);
            paramlist.Add("q_type", type);
            paramlist.Add("duration", duration);
            wsh.Post("events/" + eventToken + "/quick_start.js", paramlist);
        }

        /// <summary>
        /// Stops a the latest survey in a given event
        /// </summary>
        /// <param name="e">the event, where the latest survey shall be stopped</param>
        public static void StopSurvey(Event e)
        {
            var wsh = new WSHelper<Survey>();
            var paramlist = new System.Collections.Hashtable();
            paramlist.Add("auth_token", Settings.AUTH_TOKEN);
            paramlist.Add("stoptime", "0");
            wsh.Post("events/" + e.Token + "/surveys/" + e.LatestSurvey.Id + "/stop", paramlist);
        }
        #endregion
    }
}