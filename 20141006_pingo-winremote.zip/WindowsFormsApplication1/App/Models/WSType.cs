using System;

namespace WinRemote
{
    /// <summary>
    /// Provides the Type for the WSHelper. Requests ID and Name from its implementors.
    /// </summary>
	public interface WSType 
	{
		// [DataMember(Name="_id")]
		string Id { get; set; }
		
		// [DataMember(Name="name")]
		string Name { get; set; }
	}
}

