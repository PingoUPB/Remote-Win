using System;
using System.Collections.Generic;

namespace WinRemote
{
    /// <summary>
    /// Event class similiar to PINGO's Rails Event model, contains Id,Name, Token and LatestSurvey
    /// </summary>
	public class Event : WSType, IComparable
    {
        #region fields
        /// <summary>
        /// The event's ID
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// The event's name. Given by the user in the PINGO Webapp.
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// The event's token. Is used by participants to participate in surveys.
        /// </summary>
        public string Token { get; set; }
        /// <summary>
        /// The event's latest survey.
        /// </summary>
        public Survey LatestSurvey { get; set; }
        #endregion

        #region methods
        /// <summary>
        /// Gets all Events from Server.
        /// </summary>
        /// <returns>Sorted list of all Events the current user has access to</returns>
		public static List<Event> All() {
            
			WSHelper<Event> tws = new WSHelper<Event> ();
            var paramlist = new System.Collections.Hashtable();
            paramlist.Add("auth_token", Settings.AUTH_TOKEN);
            //Convert Json into list of Events (without latest surveys)
            var list = tws.ConvertJSONToCollection(tws.Get("events",paramlist),   e =>
            {
                return new Event { Id = (string)e["_id"], Name = (string)e["name"], Token = (string)e["token"] };
            });

            list.Sort();
            return list;
            
		}

       /// <summary>
        /// Converts a JObject into an Event
       /// </summary>
       /// <returns>Event Object converted from JSON</returns>
        public static Func<Newtonsoft.Json.Linq.JObject, Event> FromJSON()
        {
            return e =>
            {
                return new Event { Id = (string)e["_id"], Name = (string)e["name"], Token = (string)e["token"], LatestSurvey = Survey.FromJson(e["latest_survey"]) };
            };
        }
        public void ReloadLatestSurvey()
        {
            var tws = new WSHelper<Event>();
            var paramlist = new System.Collections.Hashtable();
            paramlist.Add("auth_token", Settings.AUTH_TOKEN);
            Settings.session = tws.ConvertJSONTOObj(tws.Get("events/" + Settings.session.Token, paramlist), Event.FromJSON());
        }
        /// <summary>
        /// Overrides toString method displays the event in form: Name(Token)
        /// </summary>
        /// <returns>String in format: Name(Token)</returns>
       public override string ToString()
        {
            return this.Name+" ("+Token+")";
        }

        /// <summary>
       /// Compares two Events to enable alphabetical sorting.
        /// </summary>
        /// <param name="e">The Event to be compared with.</param>
        /// <returns>Comparison result based on comparing the Events' names.</returns>
       public int CompareTo(object e) { return this.Name.CompareTo(((Event)e).Name); }

        #endregion
    }
}

