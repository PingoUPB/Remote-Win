namespace WinRemote
{
    /// <summary>
    /// User class, similiar to user model in PINGO Webapp
    /// </summary>
    public class User : WSType
    {
        #region fields
        /// <summary>
        /// Not used. Requested by WSType
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// Not used. Requested by WSType
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// The User's Authentication Token. Enables authentication without giving e-mail and password to the server.
        /// </summary>
        public string Auth_token { get; set; }
        /// <summary>
        /// true if the user's auth token is valid.
        /// </summary>
        public string Valid { get; set; }

        #endregion
        
        /// <summary>
        /// Sets the authentication token
        /// </summary>
        /// <param name="auth_token">the user's authentication token.</param>
        public User(string auth_token)
        {
            Auth_token = auth_token;
        }
        /// <summary>
        /// Default.
        /// </summary>
        public User() { }

        /// <summary>
        /// Requests the user's authentication token from server.
        /// </summary>
        /// <param name="email">the user's e-mail adress</param>
        /// <param name="password">the user's password</param>
        /// <returns>the user's auth token</returns>
        public static string authenticate(string email, string password)
        {
            var wsh = new WSHelper<User>();
            //Add parameters
            var paramlist = new System.Collections.Hashtable();
            paramlist.Add("email", email);
            paramlist.Add("password", password);
            User u = wsh.ConvertJSONTOObj(wsh.Post("api/get_auth_token", paramlist), e =>
            {//create User and set auth token
                return new User { Id = "", Name = "", Auth_token = (string)e["authentication_token"] };
            });

            return u.Auth_token;
        }
        /// <summary>
        /// Determines if the given token is a valid one, i.e. you can connect with it to the server.
        /// </summary>
        /// <param name="auth_token"></param>
        /// <returns></returns>
        public static bool valid_token(string auth_token)
        {
            var wsh = new WSHelper<User>();
            var paramlist = new System.Collections.Hashtable();
            paramlist.Add("auth_token", auth_token);

            User u = wsh.ConvertJSONTOObj(wsh.Post("api/check_auth_token", paramlist), e =>
            {
                return new User { Id = "", Name = "", Auth_token = (string)e["authentication_token"], Valid = (string)e["valid"] };
            });

            if (u.Valid.Equals("True")) return true;
            else return false;
        }

        /// <summary>
        /// Logs the User out. Deletes the token from Database and Settings.
        /// </summary>
        public static void Logout()
        {
            Settings.AUTH_TOKEN = "";
            DBController.DeleteAllUsers();
        }
    }
}