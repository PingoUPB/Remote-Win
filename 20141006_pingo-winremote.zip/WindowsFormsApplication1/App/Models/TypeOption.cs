﻿using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Globalization;

namespace WinRemote
{   
    /// <summary>
    /// Represents a one possible option of a survey type
    /// </summary>
    internal class TypeOption
    {
        #region fields
        /// <summary>
        /// The option's name used by the PINGO Server
        /// </summary>
        public string name { get; set; }
        /// <summary>
        /// The option's name used by the German translation in the webapp
        /// </summary>
        public string name_de { get; set; }
        /// <summary>
        /// The option's name used by the English translation in the webapp
        /// </summary>
        public string name_en { get; set; }
        #endregion

        #region methods
        /// <summary>
        /// Transforms JArrays into a list of TypeOptions. Is based on the assumption that the first name in the first parameter
        /// belongs to the same TypeOption as the first parameters in the second and third parameters and so on...
        /// </summary>
        /// <param name="json">JArray containing the names</param>
        /// <param name="json_de">JArray containing the</param>
        /// <param name="json_en"></param>
        /// <returns></returns>
        public static List<TypeOption> ToList(JArray json, JArray json_de, JArray json_en)
        {
            var result = new List<TypeOption>();
            if (json_de[0].ToString().Equals(""))
                /*if the first German name is set to "" then the names in the first parameter
                 * are used for the German and English names as well, is used when e.g. every option of a type is just a number like SC or MC */
                foreach (JValue jv in json)                 
                {
                    result.Add(new TypeOption(jv, jv, jv));
                }
            else
                for (int i = 0; i < json.Count; i++)
                {
                    result.Add(new TypeOption((JValue)json[i], (JValue)json_de[i], (JValue)json_en[i]));
                }
            return result;
        }

        /// <summary>
        /// Sets the TypeOption's names based on the provided JValues
        /// </summary>
        /// <param name="jv">JValue containing the name</param>
        /// <param name="jv_de">JValue containing the German name</param>
        /// <param name="jv_en">JValue containing the English name</param>
        public TypeOption(JValue jv, JValue jv_de, JValue jv_en)
        {
            this.name = jv.ToString();
            this.name_de = jv_de.ToString();
            this.name_en = jv_en.ToString();
        }

        /// <summary>
        /// Provides the Option's name depending on the users language settings. Default is English.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            if (CultureInfo.CurrentCulture.Name.Contains("de"))
                return this.name_de;
            return this.name_en;
        }
        #endregion
    }
}