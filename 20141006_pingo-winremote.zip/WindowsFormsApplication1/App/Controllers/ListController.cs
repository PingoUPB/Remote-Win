﻿using System.Collections;
using System.Collections.Generic;

namespace WinRemote
{
    /// <summary>
    /// Organizes necessary lists. Contains lists for questions and a Hashtable mapping tags and questions.
    /// </summary>
    internal class ListController
    {
        #region fields

        /// <summary>
        /// All the questions a user has.
        /// </summary>
        public List<Question> AllQuestionList { get; set; }

        /// <summary>
        /// Maps tags and questions.
        /// </summary>
        public Hashtable TagTable { get; set; }

        #endregion fields

        #region methods
        /// <summary>
        /// Builds Lists
        /// </summary>
        public ListController()
        {
            BuildAllQuestionList();
            buildTagHash();
        }

        /// <summary>
        /// Gets all Questions from Server and stores them into AllQuestionList.
        /// </summary>
        private void BuildAllQuestionList()
        {
            AllQuestionList = Question.All();
        }

        /// <summary>
        /// Builds a Hashtable which provides tag => question queries.
        /// </summary>
        private void buildTagHash()
        {
            Hashtable Tagtable = new Hashtable();
            Tagtable.Add(Properties.translate.AllTags, AllQuestionList);

            //Check every question with every tag.
            foreach (Question q in AllQuestionList)
                foreach (string t in q.Tags)
                {
                    if (Tagtable.ContainsKey(t)) //tag already in table
                        ((List<Question>)(Tagtable[t])).Add(q);
                    else //tag is not in table
                    {
                        List<Question> l = new List<Question>();
                        l.Add(q);
                        Tagtable.Add(t, l);
                    }
                }
            this.TagTable = Tagtable;
        }
        #endregion
    }
}