﻿using NDatabase;
using System;
using WinRemote.App.Models;


namespace WinRemote
{
    /// <summary>
    ///  Organizes NDatabase. Saves and retrieves user's authentication token and URLs to sockets and website.
    /// </summary>
    class DBController
    {
        #region StoreData
        /// <summary>
        /// Stores auth_token in DB.
        /// </summary>
        /// <param name="auth_token">Authentication Token to be stored.</param>
        public static void StoreAuthToken(String auth_token)
        {
            using (var odb = OdbFactory.Open(Settings.DB_NAME)) //open DB
            {
                //Delete old database entries
                foreach (User u in odb.QueryAndExecute<User>())
                    odb.Delete<User>(u);
                odb.Store(new User(auth_token));
            }
        }

        /// <summary>
        /// Stores the given URLs in the data base as an URLSettings object.
        /// </summary>
        /// <param name="base_URL">URL to PINGO website</param>
        /// <param name="base_Socket_URL">URL to socket website</param>
        public static void StoreURLs(String base_URL, String base_Socket_URL)
        {
            using (var odb = OdbFactory.Open(Settings.DB_NAME)) //open DB
            {
                //Delete old database entries
                foreach (URLSettings u in odb.QueryAndExecute<URLSettings>())
                    odb.Delete<URLSettings>(u);
                odb.Store(new URLSettings(base_URL, base_Socket_URL));
            }
        }
        #endregion

        #region QueriesAndUpdates

        /// <summary>
        /// Returns the stored URL to the PINGO website.
        /// </summary>
        /// <returns></returns>
        public static string RetrieveBaseURL()
        {
            using (var odb = OdbFactory.Open(Settings.DB_NAME))
            {
                var u = odb.QueryAndExecute<URLSettings>().GetFirst(); //Query first URLSettings Obj in DB
                if (u != null) return u.base_URL;
                else return "";
            }

        }

        /// <summary>
        /// Returns the stored URL to the socket website.
        /// </summary>
        /// <returns></returns>
        public static string RetrieveBaseSocketURL()
        {
            using (var odb = OdbFactory.Open(Settings.DB_NAME))
            {
                var u = odb.QueryAndExecute<URLSettings>().GetFirst(); //Query first User Obj in DB
                if (u != null) return u.base_Socket_URL;
                else return "";
            }

        }

     /// <summary>
     ///  Gets auth_token from DB.
     /// </summary>
     /// <returns>The current authentication token. null if no User is saved in DB.</returns>
        public static string RetrieveAuthToken()
        {
            using (var odb = OdbFactory.Open(Settings.DB_NAME))
            {
                var u= odb.QueryAndExecute<User>().GetFirst(); //Query first User Obj in DB
                if (u != null) return u.Auth_token;
                else return null;
            }
                
        }

        /// <summary>
        /// Deletes all saved Users from DB. Called on log out.
        /// </summary>
        public static void DeleteAllUsers()
        {
            using (var odb = OdbFactory.Open(Settings.DB_NAME))
            {
                foreach (User u in odb.QueryAndExecute<User>())
                    odb.Delete<User>(u);
                
            }
        }
        #endregion
    }
        
}
