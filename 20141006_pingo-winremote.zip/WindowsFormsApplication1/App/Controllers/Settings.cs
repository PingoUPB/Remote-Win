using System.Collections.Generic;

namespace WinRemote
{
    /// <summary>
    ///  Saves all the general Settings. Connects most of the other controllers with GUI 
    /// </summary>
	public class Settings
	{
        /// <summary>
        /// Reference to the running instance of MainForm in this application.
        /// </summary>
        public static MainForm f1;
        /// <summary>
        /// URL to the target PINGO Server.
        /// </summary>
		public static string BASE_URL = "https://pingo.upb.de";
        /// <summary>
        /// The URL to the target PINGO WebSocket.
        /// </summary>
        public static string BASE_SOCKET_URL = "http://socket.pingo.cc:8080/";


        /// <summary>
        /// URL to the default PINGO Server.
        /// </summary>
        public static string DEFAULT_URL = "http://pingo.upb.de";
        /// <summary>
        /// The URL to the default PINGO WebSocket.
        /// </summary>
        public static string DEFAULT_SOCKET_URL = "http://socket.pingo.cc:8080/";

        public static string BASE_SIGN_UP_URL = "http://pingo.upb.de/users/sign_up";

        /// <summary>
        /// Name for the NDatabase file.
        /// </summary>
        public static string DB_NAME = "Database.db";
        /// <summary>
        /// Current User's authentication token.
        /// </summary>
        public static string AUTH_TOKEN;
        /// <summary>
        /// Event which is currently picked. Null if none is chosen.
        /// </summary>
        public static Event session; 
        /// <summary>
        /// Instance of ListController for building necessary lists.
        /// </summary>
        private static ListController lc;
        
        /// <summary>
        /// Stores all questions of current user.
        /// </summary>
        public static List<Question> AllQuestionList;
        /// <summary>
        /// Maps tags and questions of current user.
        /// </summary>
        public static System.Collections.Hashtable Tagtable;

        /// <summary>
        ///  Initializes Questionlist and Tagtable by using ListController.
        /// </summary>
        public static void ListBuilding()
        {
         lc = new ListController();
      
         AllQuestionList = lc.AllQuestionList;
         Tagtable = lc.TagTable;
        }
        
	}
}

